#!/bin/sh
set -eu

usage() {
  cat <<'USAGE'
Usage:
  scripts/install-to-bottle.sh install /path/to/Bottle
  scripts/install-to-bottle.sh restore /path/to/Bottle
  scripts/install-to-bottle.sh list

Examples:
  scripts/install-to-bottle.sh install "$HOME/Library/Application Support/CrossOver/Bottles/Steam"
  scripts/install-to-bottle.sh restore "$HOME/Library/Application Support/CrossOver/Bottles/Steam"

Set WII_XBOX_BRIDGE_BOTTLE_ROOTS to a colon-separated list of extra folders
to scan for Wine prefixes.
USAGE
}

project_dir=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
backup_suffix=".wii-xbox-bridge.bak"
xinput_dlls="xinput1_4.dll xinput1_3.dll xinput1_2.dll xinput1_1.dll xinput9_1_0.dll"

print_if_bottle() {
  [ -d "$1/drive_c/windows/system32" ] && printf '%s\n' "$1"
}

scan_root() {
  root=$1
  depth=$2
  [ -d "$root" ] || return 0
  find "$root" -maxdepth "$depth" -path '*/drive_c/windows/system32' -type d 2>/dev/null |
    sed 's#/drive_c/windows/system32$##'
}

list_bottles() {
  {
    print_if_bottle "$HOME/.wine"
    scan_root "$HOME/Library/Application Support/CrossOver/Bottles" 5
    scan_root "$HOME/Library/Application Support/com.codeweavers.CrossOver/Bottles" 5
    scan_root "$HOME/Library/Containers/com.franke.Whisky" 7
    scan_root "$HOME/Library/Containers/com.isaacmarovitz.Whisky" 7
    scan_root "$HOME/Wine Prefixes" 6
    scan_root "$HOME/Games" 7
    scan_root "$HOME/Applications" 7
    scan_root "$HOME/Documents" 7

    if [ -n "${WII_XBOX_BRIDGE_BOTTLE_ROOTS:-}" ]; then
      old_ifs=$IFS
      IFS=:
      for root in $WII_XBOX_BRIDGE_BOTTLE_ROOTS; do
        scan_root "$root" 7
      done
      IFS=$old_ifs
    fi
  } | sort -u
}

require_file() {
  if [ ! -f "$1" ]; then
    echo "Missing: $1" >&2
    echo "Run: make dll" >&2
    exit 1
  fi
}

copy_one() {
  src=$1
  dst=$2
  if [ -f "$dst" ] && [ ! -f "$dst$backup_suffix" ]; then
    cp "$dst" "$dst$backup_suffix"
  fi
  cp "$src" "$dst"
}

install_dlls() {
  bottle=$1
  system32="$bottle/drive_c/windows/system32"
  syswow64="$bottle/drive_c/windows/syswow64"

  if [ ! -d "$system32" ]; then
    echo "Not a Wine/CrossOver/Whisky bottle: $bottle" >&2
    exit 1
  fi

  for dll in $xinput_dlls; do
    require_file "$project_dir/build/win64/$dll"
    copy_one "$project_dir/build/win64/$dll" "$system32/$dll"
    if [ -d "$syswow64" ]; then
      require_file "$project_dir/build/win32/$dll"
      copy_one "$project_dir/build/win32/$dll" "$syswow64/$dll"
    fi
  done

  user_reg="$bottle/user.reg"
  if [ ! -f "$user_reg" ]; then
    printf 'WINE REGISTRY Version 2\n\n' > "$user_reg"
  fi
  if ! grep -q 'wii-xbox-bridge overrides' "$user_reg"; then
    [ -f "$user_reg$backup_suffix" ] || cp "$user_reg" "$user_reg$backup_suffix"
    {
      printf '\n# wii-xbox-bridge overrides\n'
      printf '[Software\\\\Wine\\\\DllOverrides]\n'
      for dll in $xinput_dlls; do
        name=${dll%.dll}
        printf '"%s"="native,builtin"\n' "$name"
      done
    } >> "$user_reg"
  fi

  echo "Installed WiiXboxBridge XInput DLLs into: $bottle"
}

restore_dlls() {
  bottle=$1
  for dir in "$bottle/drive_c/windows/system32" "$bottle/drive_c/windows/syswow64"; do
    [ -d "$dir" ] || continue
    for dll in $xinput_dlls; do
      if [ -f "$dir/$dll$backup_suffix" ]; then
        mv "$dir/$dll$backup_suffix" "$dir/$dll"
      elif [ -f "$dir/$dll" ]; then
        rm -f "$dir/$dll"
      fi
    done
  done
  if [ -f "$bottle/user.reg$backup_suffix" ]; then
    mv "$bottle/user.reg$backup_suffix" "$bottle/user.reg"
  fi
  echo "Restored original XInput files in: $bottle"
}

if [ $# -lt 1 ]; then
  usage
  exit 2
fi

case "$1" in
  list)
    list_bottles
    ;;
  install)
    [ $# -eq 2 ] || { usage; exit 2; }
    install_dlls "$2"
    ;;
  restore)
    [ $# -eq 2 ] || { usage; exit 2; }
    restore_dlls "$2"
    ;;
  *)
    usage
    exit 2
    ;;
esac
